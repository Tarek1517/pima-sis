<script setup>

</script>

<template>
  <section class="mb-10 lg:mb-20">
    <Container>
        <div class="flex flex-wrap items-center lg:-mx-4">
            <div class="w-full lg:w-1/2 px-4 order-last lg:order-none">
              <div class="rounded-tr-full">
                <img src="https://img.freepik.com/free-vector/developers-robot-work-laptop-with-magnifier-industrial-cybersecurity-industrial-robotics-malware-safeguarding-industrial-robotics-concept_335657-1902.jpg?t=st=1735556549~exp=1735560149~hmac=98c28138c22839d0261163e6b35ad7678f68d289ed00b07ca8a4b73c75fa4fbd&w=900" alt="">
              </div>
            </div>
            <div class="w-full lg:w-1/2 px-4">
                <div class="flex flex-col gap-9">
                  <div>
                    <h2 class="text-2xl lg:text-3xl font-bold text-primary pb-3">Our History</h2>
                    <p class="text-sm lg:text-lg text-gray-500 max-w-lg">PIMA with the initiative of its CEO opened a new wing named Security and Intelligence Services Unit (SISU) for providing security and intelligence coverage to its esteemed clients. LaterLt Col (retd) M Rafiqul Islam took over as Head </p>
                  </div>
                  <div>
                    <h2 class="text-2xl lg:text-3xl font-bold text-primary pb-3">Our Value</h2>
                    <p class="text-sm lg:text-lg text-gray-500 max-w-lg">
                      PIMA takes pride in being, probably, the first security company in the history of Bangladesh to deploy the women folk as security guards in full khaki clad uniform (like that of its male counterpart)
                    </p>
                  </div>
                </div>
            </div>
        </div>
    </Container>
  </section>
</template>