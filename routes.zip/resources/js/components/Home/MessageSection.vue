<script setup>
</script>

<template>
    <section class="lg:mb-20">
      <Container>
          <div class="flex flex-wrap lg:-mx-4 ">
              <div class="w-full lg:w-1/2 px-4 mb-7">
                <div class="flex flex-col gap-6 items-center justify-center">
                  <h2 class="text-2xl lg:text-3xl text-primary font-semibold ">Chairman Message</h2>
                  <p class="text-center text-base text-gray-500 max-w-lg">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto consequuntur, dolore doloribus eius id in laborum magni molestiae neque nihil nostrum odit, quibusdam quis quod reiciendis sunt vero. Deleniti dignissimos est eveniet expedita explicabo, fuga ipsum itaque odio odit, officiis perferendis quidem ratione rem repudiandae similique soluta, sunt. Et, sequi!
                  </p>
                  <div class="flex items-center gap-5">
                    <img class="size-16 lg:size-32 rounded-full object-cover" src="@/assets/images/img/chairman.png" alt="">
                    <div>
                      <h2 class="text-base lg:text-xl font-semibold text-gray-600">Chairman of PIMA</h2>
                      <p class="text-sm text-gray-400">PIMA SISS</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="w-full lg:w-1/2 px-4 mb-7">
                <div class="flex flex-col gap-6 items-center justify-center">
                  <h2 class="text-2xl lg:text-3xl text-primary font-semibold ">Managing Director Message</h2>
                  <p class="text-center text-base text-gray-500 max-w-lg">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto consequuntur, dolore doloribus eius id in laborum magni molestiae neque nihil nostrum odit, quibusdam quis quod reiciendis sunt vero. Deleniti dignissimos est eveniet expedita explicabo, fuga ipsum itaque odio odit, officiis perferendis quidem ratione rem repudiandae similique soluta, sunt. Et, sequi!
                  </p>
                  <div class="flex items-center gap-5">
                    <img class="size-16 lg:size-32 rounded-full object-cover" src="@/assets/images/img/manager.png" alt="">
                    <div>
                      <h2 class="text-base lg:text-xl font-semibold text-gray-600">Managing Director of PIMA</h2>
                      <p class="text-sm text-gray-400">PIMA SISS</p>
                    </div>
                  </div>
                </div>
              </div>
          </div>
      </Container>
    </section>
</template>0