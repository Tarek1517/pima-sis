<script setup>

</script>

<template>
    <section class="lg:mb-20">
        <Container>
            <div class="flex flex-wrap lg:-mx-4">
              <div class="w-full lg:w-1/3 px-4 mb-7">
                <div class="flex flex-col gap-5 lg:gap-9 ">
                  <div class="flex items-center gap-4">
                    <img src="@/assets/images/img/img1.jpg" alt="">
                    <h2 class="text-2xl text-primary font-semibold">Our Vision</h2>
                  </div>
                  <div>
                    <img src="@/assets/images/img/img1-1.jpg" alt="">
                  </div>
                  <p class="text-sm lg:text-base text-gray-500 text-justify">
                    To provide dedicated Management and Support Services by creating ample employment opportunities for the unemployed.
                  </p>
                </div>
              </div>
              <div class="w-full lg:w-1/3 px-4 mb-7">
                <div class="flex flex-col gap-5 lg:gap-9">
                  <div class="flex items-center gap-4">
                    <img src="@/assets/images/img/img2.jpg" alt="">
                    <h2 class="text-2xl text-primary font-semibold">Our Mission</h2>
                  </div>
                  <div>
                    <img src="@/assets/images/img/img2-2.jpg" alt="">
                  </div>
                  <p class="text-sm lg:text-base text-gray-500 text-justify">
                    To ensure provisioning of flawless service in the field of Security and Integrated Support Services to the esteem clients.
                  </p>
                </div>
              </div>
              <div class="w-full lg:w-1/3 px-7 mb-7">
                <div class="flex flex-col gap-5 lg:gap-9">
                  <div class="flex items-center gap-4">
                    <img src="@/assets/images/img/img3.jpg" alt="">
                    <h2 class="text-2xl text-primary font-semibold">Our Goal</h2>
                  </div>
                  <div>
                    <img src="@/assets/images/img/img3-3.jpg" alt="">
                  </div>
                  <p class="text-sm lg:text-base  text-gray-500 text-justify">
                    To relieve the esteem clients from the day-to-day menace of time consuming administrative and operational hassles of Security and Integrated Support Services.
                  </p>
                </div>
              </div>
            </div>
        </Container>
    </section>
</template>