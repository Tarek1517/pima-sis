<script setup>
</script>

<template>
    <section class="lg:mb-20">
      <Container>
          <div class="flex flex-wrap items-center">
              <div class="w-full lg:w-1/2">
                <div>
                  <img class="w-full" src="https://images.pexels.com/photos/7362859/pexels-photo-7362859.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="">
                </div>
              </div>
              <div class="w-full lg:w-1/2">
                <div class="flex flex-col  lg:pl-20">
                  <h2 class="text-3xl font-semibold text-primary py-10">Why Choose Us</h2>
                    <p class="text-base text-gray-500 font-medium mb-5">
                      PIMA has the experience of providing Security services in various garment factories, shopping complex, constructions sites, commercial buildings, residential apartments, Dhanmondi Lake area & over 600 Banglalink BTS Towers & installations spread over Dhaka, Barisal & Khulna divisions.
                    </p>
                    <ul>
                      <li class="text-xl text-secondary font-medium mb-5">  Hassle Free
                          <p class="text-base text-gray-500 font-medium">Basing on the analysis and evaluation of the existing security threat risks PIMA recommends an optimum level and cost effective Security system to combat espionage.</p>
                      </li>
                      <li class="text-xl text-secondary font-medium mb-5">Availability
                        <p class="text-base text-gray-500 font-medium">Basing on the analysis and evaluation of the existing security threat risks PIMA recommends an optimum level and cost effective Security system to combat espionage.</p>
                      </li>
                      <li class="text-xl text-secondary font-medium mb-5">Emergency
                        <p class="text-base text-gray-500 font-medium">Basing on the analysis and evaluation of the existing security threat risks PIMA recommends an optimum level and cost effective Security system to combat espionage.</p>
                      </li>
                      <li class="text-xl text-secondary font-medium mb-5">Reserve Force
                        <p class="text-base text-gray-500 font-medium">Basing on the analysis and evaluation of the existing security threat risks PIMA recommends an optimum level and cost effective Security system to combat espionage.</p>
                      </li>
                    </ul>
                </div>
              </div>
          </div>
      </Container>
    </section>
</template>