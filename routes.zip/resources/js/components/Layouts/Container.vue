<template>
    <div class="mx-auto max-w-[90%] lg:max-w-[1180px]">
        <slot />
    </div>
</template>
