<script setup>

</script>

<template>
    <div class="flex flex-col gap-2 shadow-lg p-4 rounded-md">
      <img class="rounded-lg" src="https://fse.jegtheme.com/cryptiva/wp-content/uploads/sites/26/2024/11/it-engineer-setting-up-server-1536x1024.jpg" alt="">
      <h3 class="text-primary text-lg  font-semibold">Security & Integrated Support Services</h3>
      <p class="text-gray-500 text-sm ">
        Basing on the analysis and evaluation of the existing security threat risks PIMA recommends an optimum level and cost effective Security system.
      </p>
      <RouterLink to="/" class="text-sm text-secondary font-semibold">
        Read More
      </RouterLink>
    </div>
</template>