<template>
    <section class="bg-primary my-10 lg:my-20 py-10">
        <Container>
            <div class="flex flex-col lg:flex-row items-start gap-5 lg:gap-0 lg:items-center justify-between">
                <p class="flex items-center gap-4 text-3xl font-semibold text-black">
                    <Icon name="mdi:check-decagram" class="text-base " />
                    Creative People
                </p>
                <p class="flex items-center gap-4 text-3xl font-semibold text-black">
                    <Icon name="mdi:check-decagram" class="text-base" />
                    Good Reviews
                </p>
                <p class="flex items-center gap-4 text-3xl font-semibold text-black">
                    <Icon name="mdi:check-decagram" class="text-base" />
                    Awesome Design
                </p>
                <p class="flex items-center gap-4 text-3xl font-semibold text-black">
                    <Icon name="mdi:check-decagram" class="text-base " />
                    Fast Delivery
                </p>
            </div>
        </Container>
    </section>
</template>