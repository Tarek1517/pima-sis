<script setup>

</script>

<template>
  <button class="flex gap-2 items-center rounded px-6 py-3 text-xs tracking-wide uppercase font-medium text-white bg-secondary hover:bg-primary transition-all ease-in-out duration-500">
    <slot />
  </button>
</template>